<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Orderbalance extends Model
{
     protected $guarded = [];
}
